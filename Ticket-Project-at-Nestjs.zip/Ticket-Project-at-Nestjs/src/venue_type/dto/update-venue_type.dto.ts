export class UpdateVenueTypeDto {
  name: string;
}
