export class UpdateSeatTypeDto {
  name?: string;
}
